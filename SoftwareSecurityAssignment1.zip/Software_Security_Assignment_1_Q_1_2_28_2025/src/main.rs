//This function first filters out all non-alphanumeric characters from the input string, then converts all characters to lowercase.
//The function then checks if the stripped string is equal to the reverse of the stripped string, and returns true if it is, and false if it is not.
fn is_palindrome(s: &str) -> bool {                                                                                           // -------+--s          
    let stripped: String = s.chars().filter(|c| c.is_alphanumeric()).map(|c| c.to_ascii_lowercase()).collect();  //        |                                                                                                                  
    stripped == stripped.chars().rev().collect::<String>()                                                                    //        |                        
}                                                                                                                             //--------+--s out of scope                        
                                                                                                                            
fn main() {                                                                                                                  
    
    let valid_palindromes = vec![
    "racecar",
    "22/02/2022",
    "Was it a car or a cat I saw?",
    "A man, a plan, a canal, Panama",
    "A dog! A panic in a pagoda!",
    "A Toyota's a Toyota",
    "Never odd or even",
    "Madam, in Eden, I'm Adam",
    "No 'x' in Nixon",
    "Go hang a salami, I'm a lasagna hog"
    ];

    let invalid_palindromes = vec![
    "hello",
    "world",
    "this is not a palindrome",
    "this is also not a palindrome",
    "this is definitely not a palindrome",
    "rust", 
    "palindrome testing wooo",
    "beef and cheese sandwich from arby's",
    "Go hang a salami, I'm a lasag- ohhhh you almost got me with that one but i escaped!",
    "na hog",
    "Im blue da ba dee da ba daa",
    "da ba dee da ba daa",
    "how do you feel about the show adventure time?",
    "I think it's a pretty good show",
    "...Silence?",
    "Sorry just tryna make small talk, I'll go",
    "I eated a bug" ,
    "Or did the bug eated me",
    "Life's great questions",
    "I am a palindrome but I am not a palindrome"];

    for phrase in &valid_palindromes {                                            //--------------------+--phrase
        println!("Checking if '{}' is a palindrome: {}", phrase, is_palindrome(phrase)); //
    }                                                                                    //--------------------+--phrase out of scope                                       
    for phrase in &invalid_palindromes {                                          //--------------------+--phrase
        println!("Checking if '{}' is a palindrome: {}", phrase, is_palindrome(phrase)); //
    }                                                                                    //--------------------+--phrase out of scope
} 


#[cfg(test)]
mod tests {
    use super::*; 

    #[test]
    fn test_is_valid_palindrome() {
        let valid_palindromes = vec![
        "racecar",
        "22/02/2022",
        "Was it a car or a cat I saw?",
        "A man, a plan, a canal, Panama",
        "A dog! A panic in a pagoda!",
        "A Toyota's a Toyota",
        "Never odd or even",
        "Madam, in Eden, I'm Adam",
        "No 'x' in Nixon",
        "Go hang a salami, I'm a lasagna hog"
    ];

    
        for phrase in valid_palindromes  {
            assert!(is_palindrome(phrase), "{} should be a palindrome", phrase);
        }
    }
    
    #[test]
    fn test_is_invalid_palindrome() {
        let invalid_palindromes = vec![
        "hello",
        "world",
        "this is not a palindrome",
        "this is also not a palindrome",
        "this is definitely not a palindrome",
        "rust", 
        "palindrome testing wooo",
        "beef and cheese sandwich from arby's",
        "Go hang a salami, I'm a lasag- ohhhh you almost got me with that one but i escaped!",
        "na hog",
        "Im blue da ba dee da ba daa",
        "da ba dee da ba daa",
        "how do you feel about the show adventure time?",
        "I think it's a pretty good show",
        "...Silence?",
        "Sorry just tryna make small talk, I'll go",
        "I eated a bug" ,
        "Or did the bug eated me",
        "Life's great questions",
        "I am a palindrome but I am not a palindrome"];

        for phrase in invalid_palindromes  {
            assert!(!is_palindrome(phrase), "{} should not be a palindrome", phrase);
        }
    }
}
    
