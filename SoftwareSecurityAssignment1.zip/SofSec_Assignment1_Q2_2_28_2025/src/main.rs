use rand::Rng;
use rand::rngs::ThreadRng;
use std::io;

// Function reads a string, filters out all non alphanumeric characters from the string, and then deletes 5 random characters from the string
fn delete_a_letter(phrase: &str) -> String {
    let mut new_phrase: String = String::new();
    for c in phrase.chars() {
            if c.is_alphanumeric() {
                new_phrase.push(c);
            }
    }
    let mut rng: ThreadRng = rand::thread_rng();
    for _ in 0..5 {
        let random_number: usize = rng.gen_range(0..new_phrase.len());
        new_phrase.remove(random_number);
    }
    new_phrase
}
// Function reads a string, filters out all non alphanumeric characters from the string, and then replaces 5 random characters from the string
fn replace_a_letter(phrase: &str) -> String {
    let mut new_phrase: String = String::new();
    for c in phrase.chars() {
            if c.is_alphanumeric() {
                new_phrase.push(c);
            }
    }
    let mut rng: ThreadRng = rand::thread_rng();
    for _ in 0..5 {
        let random_number: usize = rng.gen_range(0..new_phrase.len());
        let random_char: char = rng.gen_range(33..126).into();
        new_phrase.remove(random_number);
        new_phrase.insert(random_number, random_char);
    }
    new_phrase
}
// Function reads a string, filters out all non alphanumeric characters from the string, and then inserts 5 random characters onto the string
fn insert_a_letter(phrase: &str) -> String {
    let mut new_phrase: String = String::new();
    for c in phrase.chars() {
        if c.is_alphanumeric() {
            new_phrase.push(c)
        }
    }
    let mut rng: ThreadRng = rand::thread_rng();
    for _ in 0..5 {
        let random_number: usize = rng.gen_range(0..new_phrase.len());
        let random_char: char = rng.gen_range(97..122).into();
        new_phrase.insert(random_number, random_char);
    }
    new_phrase 
}

fn main() {
    let mut phrase: String = String::new();
    println!("Enter a phrase, or enter 'q' to quit: ");
    io::stdin().read_line(&mut phrase).expect("Failed to read line");
    let new_phrase: String = delete_a_letter(&phrase);
    println!("New phrase: {}", new_phrase);
    let new_phrase: String = replace_a_letter(&phrase);
    println!("New phrase: {}", new_phrase);
    let new_phrase: String = insert_a_letter(&phrase);
    println!("New phrase: {}", new_phrase);
    
}
   
#[cfg(test)]
mod tests {
    use super::*;

    #[test] 
    fn test_delete_a_letter() {
        let phrases = vec!["GET /index.html HTTP/1.1",
        "https://www.umkc.edu/current-students/",
        "https://en.wikipedia.org/wiki/American_Fuzzy_Lop_(software)",
        "http://www.google.com"];

        for phrase in phrases {
            println!("Original phrase: {}", phrase);
            let new_phrase: String = delete_a_letter(phrase);
            println!("New phrase: {}", new_phrase);

        }
    }

    #[test]
   fn test_replace_a_letter() {
        let phrases = vec!["GET /index.html HTTP/1.1",
        "https://www.umkc.edu/current-students/",
        "https://en.wikipedia.org/wiki/American_Fuzzy_Lop_(software)",
        "http://www.google.com"];

        for phrase in phrases {
            println!("Original phrase: {}", phrase);
            let new_phrase: String = replace_a_letter(phrase);
            println!("New phrase: {}", new_phrase);
        }
    }

    #[test]
    fn test_insert_a_letter() {
        let phrases = vec!["GET /index.html HTTP/1.1",
        "https://www.umkc.edu/current-students/",
        "https://en.wikipedia.org/wiki/American_Fuzzy_Lop_(software)",
        "http://www.google.com"];

        for phrase in phrases {
            println!("Original phrase: {}", phrase);
            let new_phrase: String = insert_a_letter(phrase);
            println!("New phrase: {}", new_phrase);
        }
    }
}
