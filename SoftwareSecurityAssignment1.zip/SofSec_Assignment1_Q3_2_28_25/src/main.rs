
// function to generate SQL statement based on a company's login requirements. 
//If the requirements are met, a SQL statement is generated that will return the user's account information.
//If the requirements are not met, an error message is returned.
fn generate_sql_statement(username: &str, password: &str) -> Result<String, String>  {
    if username.contains("=") || username.contains("'") {
        return Err("Invalid: username cannot contain '=' or '\'' characters.".to_string());
    }
    if password.len() < 8 {
        return 
        Err("Password must be at least 8 characters long.".to_string());
    }

    let has_digit = password.chars().any(|c| c.is_ascii_digit());
    let has_uppercase = password.chars().any(|c| c.is_uppercase());
    let has_lowercase = password.chars().any(|c| c.is_lowercase());
    let has_special = password.chars().any(|c| "~!@$%^&".contains(c));

    if !has_digit || !has_uppercase || !has_lowercase || !has_special {
        return Err("Password must include at least one digit, one uppercase letter, one lowercase letter, and one special character.".to_string());
    }

    Ok(format!("Select * FROM accounts \n WHERE userid = '{}' \n AND password = '{}'", username, password))
    }

    #[cfg(test)]
    mod tests {
        use super::*;
    #[test]
    fn test_cases() {
        let test_cases = vec! [
        ("validUser1", "Valid1@pass"), // valid
        ("validUser2", "Valid2@pass"), // valid
        ("validUser3", "Valid3@pass"), // valid
        ("validUser4", "Valid4@pass"), // valid
        ("validUser5", "Valid5@pass"), // valid
        ("validUser6", "Valid6@pass"), // valid
        ("validUser7", "Valid7@pass"), // valid
        ("validUser8", "Valid8@pass"), // valid
        ("validUser9", "Valid9@pass"), // valid
        ("validUser10", "Valid0@pass"), // valid
        ("invalidUser=", "Valid1@pass"), // invalid username
        ("invalidUser'", "Valid2@pass"), // invalid username
        ("validUser11", "short1@"), // invalid password
        ("validUser12", "NoSpecialChar1"), // invalid password
        ("validUser13", "NoDigit@pass"), // invalid password
        ("validUser14", "NOLOWERCASE1@"), // invalid password
        ("validUser15", "nouppercase1@"), // invalid password
        ("validUser16", "Valid1pass"), // invalid password
        ("validUser17", "Valid1@"), // invalid password
        ("validUser18", "=inValid@pass"), // invalid password
        ("invalidUser=", "Valid1@pass"), // invalid username
        ("invalidUser'", "Valid2@pass"), // invalid username
        ("invalidUser1=", "Valid3@pass"), // invalid username
        ("invalidUser2'", "Valid4@pass"), // invalid username
        ("invalidUser3=", "Valid5@pass"), // invalid username
        ("invalidUser4'", "Valid6@pass"), // invalid username
        ("invalidUser5=", "Valid7@pass"), // invalid username
        ("invalidUser6'", "Valid8@pass"), // invalid username
        ("invalidUser7=", "Valid9@pass"), // invalid username
        ("invalidUser8'", "Valid0@pass"), // invalid username
        ];

        for (username, password) in test_cases {
            match generate_sql_statement(username, password)  {
                Ok(sql) => println!("Generated SQL: {}", sql),
                Err(err) => eprintln!("Error: {}", err),
            }
        }
    }
    }